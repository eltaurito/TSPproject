import subprocess

files=["fl1577.tsp","pcb442.tsp","rat783.tsp","u1060.tsp"]

import subprocess
while True:
    for filename in files:
        subprocess.call(['java', '-jar', 'AlgoritmiProgetto.jar',filename])
